<?php if (!defined('APPLICATION')) exit(); ?>

<h1><?php echo t('TermsOfService'); ?></h1>
<div class="Legal">
    <?php echo Gdn_Format::markdown(t('TermsOfServiceText')); ?>
</div>
