<?php if (!defined('APPLICATION')) exit();
$this->addonType = 'applications';
include_once PATH_APPLICATIONS.'/dashboard/views/settings/plugins.php';
