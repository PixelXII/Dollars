# SCSS Extensions

These are adapter stylesheets that map old ways of doing things to new ways. Optimally, we want this directory to be
empty, but there's some work to be done before we get there. Each file is annotated with its raison d'être and/or what 
needs to happen before we can delete the file.
